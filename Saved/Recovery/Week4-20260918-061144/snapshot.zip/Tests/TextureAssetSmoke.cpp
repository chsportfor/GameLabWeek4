#include "Core/AssetManager/Texture2DAsset.h"
#include "Core/AssetManager/FileAssetSource.h"
#include <iostream>
#include <stdexcept>

static void Check(bool Value, const char* Message)
{
    if (!Value) throw std::runtime_error(Message);
}

struct FMemorySource : FAssetSource
{
    FString Data;
    bool ReadBytes(FString& Out) const override { Out = Data; return true; }
};

int main()
{
    try
    {
        Microsoft::WRL::ComPtr<ID3D11Device> Device;
        Check(SUCCEEDED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, nullptr, 0,
            D3D11_SDK_VERSION, &Device, nullptr, nullptr)), "Create WARP device");
        FTexture2DAssetLoader Loader(Device.Get());
        FFileManager Files("EngineLib/Assets");
        for (const char* Path : { "Textures/CubeTextureSample.dds", "Textures/EarthTexture.dds",
            "Textures/Explosion_Alpha.dds", "Textures/LoadingScreen.dds", "Fonts/EnglishFont.png" })
        {
            FFileAssetSource Source(Files, Path);
            UAsset* Base = Loader.LoadAsset(FName(Path), Source);
            Check(Base && Base->IsA<UTexture2DAsset>() && Base->IsA<UAsset>(), "Load/RTTI");
            auto* Asset = Base->Cast<UTexture2DAsset>();
            Check(Asset->GetName() == FName(Path), "Asset name");
            D3D11_TEXTURE2D_DESC Desc{};
            Asset->GetTexture()->GetDesc(&Desc);
            Check(Asset->GetSRV() && Desc.Width == Asset->GetWidth() && Desc.Height == Asset->GetHeight()
                && Desc.Format == Asset->GetFormat() && Desc.MipLevels == Asset->GetMipLevels(), "Asset metadata");
            std::cout << Path << ": " << Desc.Width << 'x' << Desc.Height << ", mips=" << Desc.MipLevels << ", format=" << Desc.Format << '\n';
            Loader.UnloadAsset(Asset);
            Check(Asset->GetSRV() != nullptr, "Loader must not destroy a referenced UObject");
            Asset->Destroy();
        }
        FFileAssetSource Missing(Files, "missing-texture.dds");
        Check(!Loader.LoadAsset(FName("Missing"), Missing), "Missing file");
        FAssetSource Unsupported;
        Check(!Loader.LoadAsset(FName("Unsupported"), Unsupported), "Unsupported source");
        FMemorySource Memory;
        Check(!Loader.LoadAsset(FName("Empty"), Memory), "Empty data");
        Memory.Data = FString("not an image");
        Check(!Loader.LoadAsset(FName("Invalid"), Memory), "Invalid WIC data");
        Memory.Data = FString("DDS invalid");
        Check(!Loader.LoadAsset(FName("InvalidDDS"), Memory), "Invalid DDS data");
        FTexture2DAssetLoader NoDevice(nullptr);
        Check(!NoDevice.LoadAsset(FName("NoDevice"), Memory), "Null device");

        // Exercise WIC when COM is already initialized in a different apartment.
        HRESULT COM = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
        Check(SUCCEEDED(COM), "Initialize STA");
        FFileAssetSource PNG(Files, "Fonts/EnglishFont.png");
        UAsset* Asset = Loader.LoadAsset(FName("STA"), PNG);
        Check(Asset != nullptr, "WIC on existing STA");
        Asset->Destroy();
        CoUninitialize();
        std::cout << "PASS: DDS, WIC, metadata, UObject RTTI/lifetime, COM and failure paths\n";
    }
    catch (const std::exception& Error)
    {
        std::cerr << "FAIL: " << Error.what() << '\n';
        return 1;
    }
}
