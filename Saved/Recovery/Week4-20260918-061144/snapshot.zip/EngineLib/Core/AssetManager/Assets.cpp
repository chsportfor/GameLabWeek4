﻿#include "Assets.h"
#include "Core/IO/FileManager.h"
#include "Rendering/Renderer.h"
#include "Core/Object/ObjectFactory.h"

FString FFileAssetSource::ReadFileToString() const
{
	return FileManager.ReadFileToString(FilePath);
}

void UStaticMeshAsset::Initialize(const FName& InAssetName, URenderer& InRenderer, const FVertexSimple* InVertices, uint32 InVertexCount)
{
	SetName(InAssetName);
	VertexCount = InVertexCount;
	VertexBuffer = InRenderer.CreateVertexBuffer(InVertices, InVertexCount);

	for (uint32 i = 0; i < InVertexCount; ++i)
	{
		const FVertexSimple& Vertex = InVertices[i];
		BoundingBox.ExpandToInclude(FVector(Vertex.x, Vertex.y, Vertex.z));
	}
}

void UStaticMeshAsset::Initialize(const FName& InAssetName, URenderer& InRenderer, const FVertexSimple* InVertices, uint32 InVertexCount, const uint32* InIndices, uint32 InIndexCount)
{
	SetName(InAssetName);
	VertexCount = InVertexCount;
	IndexCount = InIndexCount;

	VertexBuffer = InRenderer.CreateVertexBuffer(InVertices, InVertexCount);
	IndexBuffer = InRenderer.CreateIndexBuffer(InIndices, InIndexCount);
	for (uint32 i = 0; i < InIndexCount; ++i)
	{
		const FVertexSimple& Vertex = InVertices[InIndices[i]];
		BoundingBox.ExpandToInclude(FVector(Vertex.x, Vertex.y, Vertex.z));
	}
}

UAsset* FStaticMeshAssetLoader::LoadAsset(const FName& AssetName, FAssetSource& AssetSource)
{
	FFileAssetSource& FileSource = static_cast<FFileAssetSource&>(AssetSource);
	FString FileContent = FileSource.ReadFileToString();
	// TODO: do something...

	const FVertexSimple* InVertices = nullptr;
	const uint32* InIndices = nullptr;
	uint32 vertexCount = 0;
	uint32 indexCount = 0;

	return FObjectFactory::ConstructObject<UStaticMeshAsset>(AssetName, Renderer, InVertices, vertexCount, InIndices, indexCount);
}

void FStaticMeshAssetLoader::UnloadAsset(UAsset* Asset)
{
	//TODO: do something with StrongPtr...
}

