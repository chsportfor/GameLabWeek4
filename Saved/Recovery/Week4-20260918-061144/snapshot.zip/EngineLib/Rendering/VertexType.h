﻿#pragma once

#include "Core/Core.h"
#include "Core/Math/Vector.h"

// 1. Define the triangle vertices
struct FVertexSimple
{
	float x, y, z;    // Position
	float nx, ny, nz;
	float r, g, b, a; // Color
	float u, v;       // Texture coordinates

	FVector GetPosition() const { return FVector(x, y, z); }
};
